#ifdef HAVE_SSE4
#include "deflate_x86.h"
#else
#include "deflate_port.h"
#endif
