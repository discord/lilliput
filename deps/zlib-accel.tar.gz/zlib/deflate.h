#ifdef HAVE_SSE42
#include "deflate_x86.h"
#else
#include "deflate_port.h"
#endif
