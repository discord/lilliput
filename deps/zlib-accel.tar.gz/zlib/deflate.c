#ifdef HAVE_SSE4
#include "deflate_x86.c"
#else
#include "deflate_port.c"
#endif
